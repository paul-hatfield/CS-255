public class Pet
{
    //Attributes of pet class
    private String petName;
    private int petAge;
    private int dogSpace;
    private int catSpace;
    private int daysStay;
    private double amountDue;

    // constructor with values for name, age, pet type, days stay and amount due
    public Pet(String petName, int petAge, int dogSpace, int catSpace, int daysStay, double amountDue) {
        this.petName = petName;
        this.petAge = petAge;
        this.dogSpace = dogSpace;
        this.catSpace = catSpace;
        this.daysStay = daysStay;
        this.amountDue = amountDue;
    }

    // return the petName -- AKA getter
    public String getPetName()
    {
        return petName;
    }

    //petName the petName to set -- AKA setter
    public void setPetName(String petName)
    {
        this.petName = petName;
    }

    // return the petAge -- AKA getter
    public int getPetAge()
    {
        return petAge;
    }


    // setter for petAge
    public void setPetAge(int petAge)
    {
        this.petAge = petAge;
    }

    // return the dogSpace -- AKA getter
    public int getDogSpace()
    {
        return dogSpace;
    }

    // setter for dogSpace
    public void setDogSpace(int dogSpace)
    {
        this.dogSpace = dogSpace;
    }

    // return the catSpace  -- AKA getter
    public int getCatSpace()
    {
        return catSpace;
    }

    // setter for catSpace
    public void setCatSpace(int catSpace)
    {
        this.catSpace = catSpace;
    }

    // return the daysStay -- AKA getter
    public int getDaysStay()
    {
        return daysStay;
    }

    // setter for daysStay
    public void setDaysStay(int daysStay)
    {
        this.daysStay = daysStay;
    }

    // return the amountDue  -- AKA getter
    public double getAmountDue()
    {
        return amountDue;
    }

    // setter for amountDue
    public void setAmountDue(double amountDue)
    {
        this.amountDue = amountDue;
    }
}